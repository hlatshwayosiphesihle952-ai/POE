/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/UnitTests/JUnit5TestClass.java to edit this template
 */

import java.io.FileWriter;
import java.util.ArrayList;
import java.util.List;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.AfterAll;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

/**
 *
 * @author Student
 */
public class NewEmptyJUnitTest {
    
    public NewEmptyJUnitTest() {
    }
    
    @BeforeAll
    public static void setUpClass() {
    }
    
    @AfterAll
    public static void tearDownClass() {
    }
    
    @BeforeEach
    public void setUp() {
    }
    
    @AfterEach
    public void tearDown() {
    }

    // TODO add test methods here.
    // The methods must be annotated with annotation @Test. For example:
    //
    // @Test
    // public void hello() {}
}
public class Message {
    private final String messageID;
    private final String recipient;
    private final String message;
    private static int totalMessages = 0;
    private static final List<Message> sentMessages = new ArrayList<>();

    // constructor
    public Message(String messageID, String recipient, String message) {
        this.messageID = messageID;
        this.recipient = recipient;
        this.message = message;
    }

    // Check Message ID length
    public boolean checkMessageID() {
        return messageID.length() <= 10;
    }

    // Validate recipient cell number
    public String checkRecipientCell() {
        if (recipient.length() <= 10 && recipient.startsWith("+")) {
            return "Valid recipient";
        }
        return "Invalid recipient";
    }

    //  Create Message Hash
    public String createMessageHash() {
        String[] words = message.split(" ");
        String firstWord = words[0];
        String lastWord = words[words.length - 1];
        return messageID.substring(0, 2) + ":" + totalMessages + ":" +
               (firstWord + lastWord).toUpperCase();
    }

    //  Send, Store, or Disregard
    public String sentMessage(String option) {
        switch(option.toLowerCase()) {
            case "send" -> {
                sentMessages.add(this);
                totalMessages++;
                return "Message successfully sent";
            }
            case "store" -> {
                return "Message successfully stored";
            }
            case "disregard" -> {
                return "Message deleted";
            }
            default -> {
                return "Invalid option";
            }
        }
    }

    //️ Print all messages
    public static void printMessages() {
        for (Message msg : sentMessages) {
            System.out.println("ID: " + msg.messageID +
                               " | Hash: " + msg.createMessageHash() +
                               " | Recipient: " + msg.recipient +
                               " | Message: " + msg.message);
        }
    }

    // Return total messages
    public static int returnTotalMessages() {
        return totalMessages;
    }

    // Store messages in JSON file
    public static void storeMessageJSON() {
        JSONArray messageList = new JSONArray();
        for (Message msg : sentMessages) {
            JSONObject obj = new JSONObject();
            obj.put("MessageID", msg.messageID);
            obj.put("MessageHash", msg.createMessageHash());
            obj.put("Recipient", msg.recipient);
            obj.put("Message", msg.message);
            messageList.add(obj);
        }
        try (FileWriter file = new FileWriter("messages.json")) {
            file.write(messageList.toJSONString());
            file.flush();
        } catch (Exception e) {
        }
    }

    private static class JSONArray {

        public JSONArray() {
        }

        private char[] toJSONString() {
            throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
        }
    }
}
public class MessageTest {

    //Test 1
    public void testMessageLengthSuccess() {
        Message msg = new Message("1234567890", "+27718693002", "Hi Mike, can you join us for dinner tonight?");
        assertEquals("Message ready to send.", msg.validateMessageLength());
    }

    public void testMessageLengthFailure() {
        String longMessage = "A".repeat(260);
        Message msg = new Message("1234567890", "+27718693002", longMessage);
        assertEquals("Message exceeds 250 characters by 10; please reduce the size.", msg.validateMessageLength());
    }

    public void testRecipientSuccess() {
        Message msg = new Message("1234567890", "+27718693002", "Hello");
        assertEquals("Cell phone number successfully captured.", msg.checkRecipientCell());
    }

    public void testRecipientFailure() {
        Message msg = new Message("1234567890", "08575975889", "Hello");
        assertEquals("Cell phone number is incorrectly formatted or does not contain an international code. Please correct the number and try again.", msg.checkRecipientCell());
    }
    public void testMessageHash() {
        Message msg = new Message("0012345678", "+27718693002", "Hi Mike, can you join us for dinner tonight?");
        assertEquals("00:0:HITONIGHT", msg.createMessageHash());
    }
   
    public void testSendMessage() {
        Message msg = new Message("1234567890", "+27718693002", "Hello");
        assertEquals("Message successfully sent.", msg.sentMessage("send"));
    }

    //Test
    public void testStoreMessage() {
        Message msg = new Message("1234567890", "+27718693002", "Hello");
        assertEquals("Message successfully stored.", msg.sentMessage("store"));
    }

    public void testDisregardMessage() {
        Message msg = new Message("1234567890", "+27718693002", "Hello");
        assertEquals("Press 0 to delete the message.", msg.sentMessage("disregard"));
    }

    public void testTotalMessages() {
        Message msg1 = new Message("1234567890", "+27718693002", "Hello");
        msg1.sentMessage("send");
        Message msg2 = new Message("0987654321", "+27718693003", "Hi again");
        msg2.sentMessage("send");

        assertEquals(2, Message.returnTotalMessages());
    }


    
    
    private void assertEquals(int returnTotalMessages, int returnTotalMessages1) {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

    private void assertEquals(String hitonight, String createMessageHash) {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }
}

