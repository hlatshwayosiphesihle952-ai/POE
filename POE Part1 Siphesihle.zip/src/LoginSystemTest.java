import java.util.Scanner;



public class LoginSystemTest {

    LoginSystem system = new LoginSystem();


    void testUsernameCorrectlyFormatted() {
        String result = system.registerUsername("kyl_1");

        assertEquals(
            "Welcome <user first name>, <user last name> it is great to see you.",
            result
        );
    }

    void testUsernameIncorrectlyFormatted() {
        String result = system.registerUsername("kyle!!!!!!");

        assertEquals(
            "Username is not correctly formatted; please ensure that your username contains an underscore and is no more than five characters in length.",
            result
        );
    }

    @SuppressWarnings("unused")
    void testUsernameBooleanTrue() {
        assertTrue(system.isValidUsername("kyl_1"));
    }

    
    void testUsernameBooleanFalse() {
        assertFalse(system.isValidUsername("kyle!!!!!!"));
    }
    void testPasswordMeetsComplexity() {
        String result = system.registerPassword("Ch&&sec@ke99!");

        assertEquals("Password successfully captured.", result);
    }

   
    void testPasswordDoesNotMeetComplexity() {
        String result = system.registerPassword("password");

        assertEquals(
            "Password is not correctly formatted; please ensure that the password contains at least eight characters, a capital letter, a number, and a special character.",
            result
        );
    }

    void testPasswordBooleanTrue() {
        assertTrue(system.isValidPassword("Ch&&sec@ke99!"));
    }

    void testPasswordBooleanFalse() {
        assertFalse(system.isValidPassword("password"));
    }
    void testPhoneCorrectlyFormatted() {
        String result = system.registerPhone("+27838968976");

        assertEquals("Cell number successfully captured.", result);
    }

    void testPhoneIncorrectlyFormatted() {
        String result = system.registerPhone("08966553");

        assertEquals(
            "Cell number is incorrectly formatted or does not contain an international code; please correct the number and try again.",
            result
        );
    }

   void testPhoneBooleanTrue() {
        assertTrue(system.isValidPhone("+27838968976"));
    }

    void testPhoneBooleanFalse() {
        assertFalse(system.isValidPhone("08966553"));
    }
   void testLoginSuccessful() {
        assertTrue(system.logIn("kyl_1", "Ch&&sec@ke99!"));
    }

   void testLoginFailed() {
        assertFalse(system.logIn("wrong_user", "wrong_pass"));
    }

    private void assertEquals(String welcome_user_first_name_user_last_name_it, String result) {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

    
    }



